# ?? StockPilot AI � Prasunex Innovathon Round 3 Submission

### Prototype Overview
**StockPilot AI** is an enterprise-grade B2B SaaS decision-support system built for Online Travel Agencies (OTAs), hotel procurement directors, and travel inventory managers to optimize wholesale purchasing and revenue management of perishable travel inventory (hotel rooms, flight seats, resort villas).

---

### ?? Live Production Application
- **Live Production URL (Vercel):** https://stock-pilot-ai-eight.vercel.app/
- **Live Backend API (Render):** https://stockpilot-ai-ui9o.onrender.com/api/health
- **GitHub Repository:** https://github.com/Ganesh-commit/StockPilot-AI

---

### ?? Instant Evaluation Guide

#### Option A: Live Demo (No Installation Required)
1. Navigate to: https://stock-pilot-ai-eight.vercel.app/
2. Click "Try Live Demo"
3. Access all 14 functional modules: Demand Forecasting (P10/P50/P90), Forecast Accuracy Backtesting, Autonomous Procurement Engine, Newsvendor Optimizer, Knapsack Budget Allocation, Inventory Catalog, Spoilage Risk Analysis, and Scenario Simulation.

#### Option B: Local Docker Startup (1 Command)
```bash
docker-compose up --build
```
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000

#### Option C: Standard Node.js Setup
1. **Server:**
   ```bash
   cd stockpilot-mern/server
   npm install
   npm run dev
   ```
2. **Client:**
   ```bash
   cd stockpilot-mern/client
   npm install
   npm run dev
   ```
