# ?? StockPilot AI � Prasunex Innovathon Round 3 Submission

### Prototype Overview
**StockPilot AI** is an enterprise B2B SaaS decision-support platform designed for Online Travel Agencies (OTAs), hotel chains, and tour operators to optimize wholesale procurement, multi-horizon demand forecasting, and risk-adjusted capital allocation for perishable travel inventory.

---

### ?? Live Hosted Prototype & Verification Links
- **Production Web Application (Vercel):** [https://stock-pilot-ai-eight.vercel.app/](https://stock-pilot-ai-eight.vercel.app/)
- **Live Backend API (Render):** [https://stockpilot-ai-ui9o.onrender.com/api/health](https://stockpilot-ai-ui9o.onrender.com/api/health)
- **GitHub Repository:** [https://github.com/Ganesh-commit/StockPilot-AI](https://github.com/Ganesh-commit/StockPilot-AI)

---

### ?? Instant Evaluation (No Setup Required)
You can test the complete system immediately on the live deployed web application:
1. Open [https://stock-pilot-ai-eight.vercel.app/](https://stock-pilot-ai-eight.vercel.app/)
2. Click **"Try Live Demo"** (or use Demo Visitor credentials)
3. Explore the 14 integrated modules:
   - Demand Forecasting with P10/P50/P90 confidence intervals
   - Forecast Accuracy & 26-week backtesting
   - Autonomous Procurement Engine (PRE-BUY / BUY PARTLY / SKIP)
   - Newsvendor Economic Order Quantity Optimizer
   - Greedy Fractional Knapsack Budget Optimizer (?1 Cr - ?50 Cr)
   - Inventory Catalog & Real-time CRUD
   - Perishable Spoilage Risk Analysis
   - What-If Scenario Simulator & Supplier Intelligence

---

### ?? Local Execution Guide

#### Option A: Docker Compose (1-Command Startup)
`ash
docker-compose up --build
`
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000

#### Option B: Standard Node.js Setup

**Prerequisites:** Node.js v18+ and npm v9+

1. **Backend Server:**
   `ash
   cd stockpilot-mern/server
   npm install
   npm run dev
   `
   *Runs on http://localhost:5000 (operates with zero-config in-memory fallback if MongoDB is not running locally).*

2. **Frontend Client:**
   `ash
   cd stockpilot-mern/client
   npm install
   npm run dev
   `
   *Runs on http://localhost:5173.*

---

### ?? Submission Package Integrity
- **Total Excluded:** All 
ode_modules folders, .git history, .env files with private secrets, and temporary build caches.
- **Total Included:** 100% of source code, React components, Tailwind styling, Express API routes, mathematical modeling libraries, Mongoose schemas, Dockerfiles, public assets, and documentation.
